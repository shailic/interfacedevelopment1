// These are my variables
var currentAge = 24;
var maxAge = 100;
var estAmtDaily = 2;

// var statement = "You will need " + ((maxAge - currentAge) * 365 * estAmtDaily) + " granola bars to last you until the ripe old age of " + maxAge + ".";

// Output
$('.output').html("<p>You will need " + ((maxAge - currentAge) * 365 * estAmtDaily) + " granola bars to last you until the ripe old age of " + maxAge + ".</p>");


// End.
