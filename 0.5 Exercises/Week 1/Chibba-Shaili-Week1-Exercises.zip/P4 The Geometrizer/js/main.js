// These are my variables
var cirRadius = 4;

// var circumferance = "The circumferance is " + (2 * 3.14 * cirRadius) + ".";
// var area = "The area is " + (3.14 * (cirRadius * cirRadius)) + ".";

// Output
$('.output').html("<p>If the radius of your circle is " + cirRadius + ":</p>" + "<p>The circumferance is " + (2 * 3.14 * cirRadius) + ".</p>" + "<p>The area is " + (3.14 * (cirRadius * cirRadius)) + ".</p>");

// End.
