#Combination lock

Solve the combination by clicking each dial to increase it by one. As each `.dial` changes, check the current condition and let the user know how close they are to solving it by changing the `background-color` of the page.

Each time a button is clicked, check the combo:
- If no number are correct, the background should be #d27666
- If any one number is correct, the background should be #e69458
- if any two numbers are correct, the background should be #e3cb67
- If any three numbers are correct, the background should be #bcdd4e

Try to solve this with the lease number of condition checks.
